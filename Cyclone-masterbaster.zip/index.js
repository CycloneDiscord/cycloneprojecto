//---------------------------------------------------------------------------------------------------------------------------------------

const Discord = require("discord.js");
const fs = require("fs");
const Mongoose = require("mongoose")
const Perspective = require("perspective-api-client");
const prefixModel = require("./models/prefix")

const apikeys = require("./apikeys.json");
const botconfig = require("./botconfig.json")
const dbconfig = require("./database.json")

const perspective = new Perspective({apiKey: apikeys.PERSPECTIVE});

const bot = new Discord.Client();
bot.commands = new Discord.Collection();

fs.readdir("./commands/", (err, files) => {

    if(err) console.log(err);

    let jsfile = files.filter(f => f.split(".").pop() === "js");

    if(jsfile.length <= 0) {
        

        console.log("Couldn't find commands!");
        return;

    }

    jsfile.forEach((f, i) => {

        let props = require(`./commands/${f}`);
        console.log(`${f} loaded!`)

        bot.commands.set(props.help.name, props);

    });

});

bot.on("guildCreate", async guild => {

 await bot.guilds.keyArray().forEach(id => {

        prefixModel.findOne({
    
            guildID: id
    
        }, (err, guild) => {
    
            if(err) console.error(err);
    
            if(!guild) {
                const newPrefix = new prefixModel({
    
                    guildID: id,
                    prefix: botconfig.PREFIX
    
                })
    
                return newPrefix.save().catch(err => console.error(err));
    
            }
    
        })
    
    })

 let channelID;
    let channels = guild.channels;
    channelLoop:
    for (let c of channels) {
        let channelType = c[1].type;
        if (channelType === "text") {
            channelID = c[0];
            break channelLoop;
        }
    }



    let channel = bot.channels.get(guild.systemChannelID || channelID);
    let  newembed = new Discord.RichEmbed()
    .setAuthor("Greetings Everyone!")
    .setColor("#ffffff")
    .setDescription("Thank you for inviting me to this server, my default prefix is `!` and you can use `!help` to get my list of commands! \n Hope you have a nice time with me! \ Support server link: https://discord.gg/VGY3eZc")
    .setFooter("Cyclone Bot", bot.user.displayAvatarURL)
    .setTimestamp();
    channel.send(newembed);

 bot.user.setActivity(`!help `, {"type": "WATCHING"});

})

bot.on("guildDelete", async guild => {

    bot.user.setActivity(`!help`, {"type": "WATCHING"});

}) 

bot.on("ready", async() => {
        
    await Mongoose.connect("mongodb+srv://xtbot-ry2qc.mongodb.net/test", {

    user: dbconfig.USER,
    pass: dbconfig.PASS,
    useNewUrlParser: true

    }, err => { 

        if(err) return console.error(err); 
        console.log("Connected to the database")
    
    })
    
    console.log(`${bot.user.username} is up and running!`);
    bot.user.setActivity(`${bot.guilds.size} servers!`, {"type": "WATCHING"});
  
    
});



bot.on("message", async message => {
  
  if(message.author.bot) return;
    
    
            let text = message.content;
            
            if(!text) return;
            
            let result = await perspective.analyze(text, {attributes: ["SEVERE_TOXICITY"]});
    
            if(result.attributeScores.SEVERE_TOXICITY.summaryScore.value >= 0.5){ 
                message.channel.send(`:negative_squared_cross_mark: ${message.author} Don't be toxic!`); 
                message.delete();
             } 
  
})

bot.on("message", async message => {
    
    
            
            
    await bot.guilds.keyArray().forEach(id => {

        prefixModel.findOne({
    
            guildID: id
    
        }, (err, guild) => {
    
            if(err) console.error(err);
    
            if(!guild) {
                const newPrefix = new prefixModel({
    
                    guildID: id,
                    prefix: botconfig.PREFIX
    
                })
    
                return newPrefix.save().catch(err => console.error(err));
    
            }
    
        })
    
    })
    
    prefixModel.findOne({
    
            guildID: message.guild.id
    
        }, (err, guild) => {
    
        if(err) console.error(err);
    
        let prefix = guild.prefix;
        
        
        if(message.author.bot) return;
        if(message.channel.type === "dm") return;
    
        let messageArray = message.content.split(" ");
        let cmd = messageArray[0];
        let args = messageArray.slice(prefix.length);
    
        let commandfile = bot.commands.get(cmd.slice(prefix.length));
        if(!message.content.startsWith(prefix)) return;
        if(commandfile) commandfile.run(bot, message, args)
    
    })
        
    
})


bot.login(botconfig.TOKEN);